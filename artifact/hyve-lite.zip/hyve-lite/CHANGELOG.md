#### [Version 1.1.0](https://github.com/Codeinwp/hyve-lite/compare/v1.0.0...v1.1.0) (2024-09-09)

- Initial version.

####   Version 1.0.0 (2024-07-15)

- Initial release of free version of Hyve
