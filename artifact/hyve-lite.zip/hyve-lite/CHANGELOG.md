####   Version 1.0.0 (2024-07-15)

- Initial release of free version of Hyve
